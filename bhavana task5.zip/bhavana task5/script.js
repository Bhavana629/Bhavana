document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    let isValid = true;
    const username = document.getElementById("username");
    const password = document.getElementById("password");
    const errorMessages = document.querySelectorAll(".error-message");
    errorMessages.forEach(msg => msg.textContent = "");
    if (username.value.trim() === "") {
        username.nextElementSibling.textContent = "Username is required.";
        isValid = false;
    }
    if (password.value.trim() === "") {
        password.nextElementSibling.textContent = "Password is required.";
        isValid = false;
    }
    if (isValid) {
        alert("Login successful!");
    }
});