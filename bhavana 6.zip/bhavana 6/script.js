document.addEventListener("DOMContentLoaded", loadTasks);

function addTask() {
    let taskInput = document.getElementById("taskInput");
    let taskDateInput = document.getElementById("taskDate");

    let taskText = taskInput.value.trim();
    let taskDate = taskDateInput.value;

    if (taskText === "") {
        alert("Please enter a task.");
        return;
    }

    let taskList = document.getElementById("taskList");

    let li = document.createElement("li");
    li.innerHTML = `
        <input type="checkbox" onchange="toggleTask(this)">
        <div class="task-info">
            <span>${taskText}</span>
            <span class="task-date">${taskDate ? "Due: " + taskDate : "No due date"}</span>
        </div>
        <button class="delete-btn" onclick="deleteTask(this)">Delete</button>
    `;

    taskList.appendChild(li);
    saveTasks();

    taskInput.value = "";
    taskDateInput.value = "";
}

function toggleTask(checkbox) {
    let taskSpan = checkbox.nextElementSibling.querySelector("span");
    taskSpan.classList.toggle("completed", checkbox.checked);
    saveTasks();
}

function deleteTask(button) {
    button.parentElement.remove();
    saveTasks();
}

function saveTasks() {
    let tasks = [];
    document.querySelectorAll("#taskList li").forEach((li) => {
        tasks.push({
            text: li.querySelector(".task-info span").innerText,
            completed: li.querySelector("input").checked,
            date: li.querySelector(".task-date").innerText.replace("Due: ", "")
        });
    });

    localStorage.setItem("tasks", JSON.stringify(tasks));
}

function loadTasks() {
    let storedTasks = JSON.parse(localStorage.getItem("tasks")) || [];

    let taskList = document.getElementById("taskList");
    taskList.innerHTML = "";

    storedTasks.forEach((task) => {
        let li = document.createElement("li");
        li.innerHTML = `
            <input type="checkbox" onchange="toggleTask(this)" ${task.completed ? "checked" : ""}>
            <div class="task-info">
                <span class="${task.completed ? "completed" : ""}">${task.text}</span>
                <span class="task-date">${task.date ? "Due: " + task.date : "No due date"}</span>
            </div>
            <button class="delete-btn" onclick="deleteTask(this)">Delete</button>
        `;
        taskList.appendChild(li);
    });
}