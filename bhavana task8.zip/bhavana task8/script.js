let index = 0;
        const slides = document.querySelectorAll('.slider img');
        const totalSlides = slides.length;

        function showSlide(n) {
            if (n >= totalSlides) { index = 0; }
            else if (n < 0) { index = totalSlides - 1; }
            else { index = n; }

            document.querySelector('.slider').style.transform = `translateX(${-index * 100}%)`;
        }

        function nextSlide() {
            showSlide(index + 1);
        }

        function prevSlide() {
            showSlide(index - 1);
        }

        function autoSlide() {
            nextSlide();
            setTimeout(autoSlide, 3000);
        }

        setTimeout(autoSlide, 3000);